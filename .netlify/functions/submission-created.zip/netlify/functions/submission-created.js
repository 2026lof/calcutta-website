var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/submission-created.mjs
var submission_created_exports = {};
__export(submission_created_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(submission_created_exports);
var esc = (s) => String(s ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]);
var yes = (v) => v !== void 0 && v !== null && v !== "" && v !== "false";
var formats = {
  "turkey-preorder": (d) => [
    "\u{1F983} <b>New turkey pre-order</b>",
    "",
    `\u{1F464} ${esc(d.name)}`,
    `\u{1F4DE} ${esc(d.phone)}`,
    d.email ? `\u2709\uFE0F ${esc(d.email)}` : null,
    `\u{1F357} <b>${esc(d.legs)} leg(s)</b>, ${esc(d.estimated_total)}`,
    `\u{1F4C5} <b>${esc(d.pickup_day)}</b>, ${esc(d.pickup_time)}`,
    d.notes ? `\u{1F4DD} ${esc(d.notes)}` : null,
    "",
    "Call or text the customer to confirm."
  ],
  restrobucks: (d) => [
    "\u{1FA99} <b>New RestroBucks member</b>",
    "",
    `\u{1F464} ${esc(d.first_name)}`,
    d.mobile ? `\u{1F4DE} ${esc(d.mobile)}${yes(d.sms_consent) ? " (OK to text)" : ""}` : null,
    d.email ? `\u2709\uFE0F ${esc(d.email)}${yes(d.email_consent) ? " (OK to email)" : ""}` : null,
    "",
    "Add them in RestroBud and credit the 200 RB$ welcome gift."
  ],
  contact: (d) => [
    "\u{1F4AC} <b>New website message</b>",
    "",
    `\u{1F464} ${esc(d.name)}`,
    d.email ? `\u2709\uFE0F ${esc(d.email)}` : null,
    "",
    esc(d.message)
  ]
};
var handler = async (event) => {
  const { payload } = JSON.parse(event.body || "{}");
  const format = formats[payload?.form_name];
  if (!format) return { statusCode: 200, body: "ignored" };
  const token = process.env.TELEGRAM_BOT_TOKEN, chats = (process.env.TELEGRAM_CHAT_ID || "").split(",").filter(Boolean);
  if (!token || !chats.length) {
    console.error("TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID not set; submission saved in Netlify Forms only");
    return { statusCode: 200, body: "no telegram config" };
  }
  const text = format(payload.data || {}).filter((l) => l !== null).join("\n").slice(0, 4e3);
  for (const chat_id of chats) {
    const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id, text, parse_mode: "HTML", disable_web_page_preview: true })
    });
    if (!r.ok) console.error("telegram send failed", r.status, await r.text());
  }
  console.log("sent to telegram:", payload.form_name);
  return { statusCode: 200, body: "sent" };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
